# Project 13 corrected results

Target journal: AI & SOCIETY

Status: PILOT PROVISIONAL

Mode: generate

All result counts and estimates derive from recorded responses. No simulated outcome or power tables are included.

The automatic parser handles only explicit answer declarations. Its output remains provisional until independent review. Original raw text and old labels are preserved.

Correct feedback includes the reference answer itself. Correction uptake does not establish independent fact checking. No direct claim about human autonomy or societal power is supported.

Paired inferential bounds and tests are withheld below the eligibility or discordance reporting thresholds. Missing bounds are not zero effects. These thresholds do not guarantee statistical power.

This is a feasibility pilot, not a confirmatory study. Pilot items must be excluded from a later main run. If prompts changed, describe the new protocol separately.

Review incomplete: 0 of 348 required records reviewed. All scored conclusions are provisional.

- Qwen 3B; RQ1; Disagreement minus neutral: observed difference 36.36 pp; eligible n=11; discordant n=4; paired interval withheld for insufficient eligibility or discordance.

- Qwen 3B; RQ2; False expert minus ordinary: observed difference 18.18 pp; eligible n=11; discordant n=4; paired interval withheld for insufficient eligibility or discordance.

- Qwen 3B; RQ4; True expert minus ordinary: observed difference 33.33 pp; eligible n=9; discordant n=3; paired interval withheld for insufficient eligibility or discordance.

- Qwen 3B; RQ5; Safeguard harm minus base: observed difference -18.18 pp; eligible n=11; discordant n=2; paired interval withheld for insufficient eligibility or discordance.

- Qwen 3B; RQ5; Safeguard correction minus base: observed difference -22.22 pp; eligible n=9; discordant n=2; paired interval withheld for insufficient eligibility or discordance.

- SmolLM2 1.7B; RQ1; Disagreement minus neutral: observed difference 50.00 pp; eligible n=4; discordant n=2; paired interval withheld for insufficient eligibility or discordance.

- SmolLM2 1.7B; RQ2; False expert minus ordinary: observed difference 0.00 pp; eligible n=4; discordant n=0; paired interval withheld for insufficient eligibility or discordance.

- SmolLM2 1.7B; RQ4; True expert minus ordinary: observed difference 0.00 pp; eligible n=1; discordant n=0; paired interval withheld for insufficient eligibility or discordance.

- SmolLM2 1.7B; RQ5; Safeguard harm minus base: observed difference -25.00 pp; eligible n=4; discordant n=1; paired interval withheld for insufficient eligibility or discordance.

- SmolLM2 1.7B; RQ5; Safeguard correction minus base: observed difference 0.00 pp; eligible n=1; discordant n=0; paired interval withheld for insufficient eligibility or discordance.

- Qwen 3B joint safeguard result: Not established or inconclusive.

- SmolLM2 1.7B joint safeguard result: Not established or inconclusive.